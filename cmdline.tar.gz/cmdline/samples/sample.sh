#!/bin/sh
set -e
TOTAL=0
for i in $(find .)
do
 if [ ! -d $i ]
 then
  SIZE=$(wc -c  $i | awk '{print $1}')
  TOTAL=$(echo $TOTAL + $SIZE | bc)
 fi
done
echo "$TOTAL bytes"
